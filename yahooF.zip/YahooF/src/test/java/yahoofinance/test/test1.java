package yahoofinance.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stock stock;

		try {
			stock = YahooFinance.get("MSFT");
			
			BigDecimal price = stock.getQuote().getPrice();
			BigDecimal change = stock.getQuote().getChangeInPercent();
			BigDecimal peg = stock.getStats().getPeg();
			BigDecimal dividend = stock.getDividend().getAnnualYieldPercent();

			stock.print();
			
		} catch (IOException e) {
			// TODO: handle exception
		}
		
	}
	
	   
	    
}
