package yahoofinance.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.Interval;

public class test3 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		
		File file = new File("C:\\Java\\java_bigdata\\data/fdata.csv");
		FileOutputStream fos = new FileOutputStream(file);
		PrintStream ps = new PrintStream(fos);
		System.setOut(ps);
		
		Stock tesla = YahooFinance.get("TSLA", true);
		Stock intel = YahooFinance.get("INTC", true);
		Stock BABA = YahooFinance.get("BABA", true);
		Stock google = YahooFinance.get("GOOG", true);
		System.out.println(tesla.getHistory());
		System.out.println(intel.getHistory());
		System.out.println(BABA.getHistory());
		System.out.println(google.getHistory());
		
//		PrintStream consol = System.out;
//		System.setOut(consol);
		
	}

}
