package yahoofinance.test;

import java.io.IOException;
import java.util.Map;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class test2 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

		String[] symbols = new String[] {"INTC", "BABA", "TSLA", "AIR.PA", "YHOO"};
		Map<String, Stock> stocks = YahooFinance.get(symbols); // single request
		Stock intel = stocks.get("INTC");
		Stock airbus = stocks.get("AIR.PA");
		Stock TSLA = stocks.get("TSLA");
		Stock BABA = stocks.get("BABA");
		
		intel.print();
		airbus.print();	
		TSLA.print();	
		BABA.print();	
		
	}

}
